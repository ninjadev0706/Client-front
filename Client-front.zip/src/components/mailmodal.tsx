import React from "react";

const mailmodal = () => {
  return (
    <>
    </>
  );
};

export default mailmodal;

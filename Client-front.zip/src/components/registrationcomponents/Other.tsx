import React, { useEffect, useState } from "react";
import Tippy from "@tippyjs/react";
import Select from "react-select";

const customStyle = {
  control: (provided: any, state: any) => ({
    border: "none",
    display: "flex",
  }),
};

const Other = (props: any) => {
  const {
    
  } = props;

  return (
    <div className="grid md:grid-cols-2 gap-5">
      
    </div>
  );
};

export default Other;

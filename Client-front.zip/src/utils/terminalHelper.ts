export const newLine = (text: string) => `\r\n${text}`;

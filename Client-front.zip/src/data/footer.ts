export const footerBottomLinks = [
  [
    {
      title: "sAssets",
      link: "#",
    },
    {
      title: "Bug Bounty",
      link: "#",
    },
    {
      title: "Flash Loans",
      link: "#",
    },
    {
      title: "Rate Switching",
      link: "#",
    },
  ],
  [
    {
      title: "Technical Paper",
      link: "#",
    },
    {
      title: "Careers",
      link: "https://withspade.com/careers",
    },
    { title: "Privacy Policy", link: "https://withspade.com/our-company" },
  ],
  [
    { title: "Branding", link: "#" },
    { title: "Blog", link: "https://blog.withspade.com/" },
    { title: "Contact", link: "#" },
    { title: "Terms of Use", link: "https://withspade.com/transparency" },
  ],
];
